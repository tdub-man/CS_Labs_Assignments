package cs1302.linkedList.test;


import java.lang.reflect.Field;

/**
 * Created by Ben on 4/13/2016.
 */
public class Preliminary {

    public static void main(String[] args) throws NoSuchFieldException, IllegalAccessException {
//        Class<DList> cdl = DList.class;
//        Field base = cdl.getDeclaredField("base");
//        base.setAccessible(true);
//        DList dl = new DList();
//        DList.Node bval = (DList.Node)base.get(dl);
//        System.out.println("bval: " + bval);
//        System.out.println("prev? " + (bval.previous == bval) );
//        base.set(dl, null);
//        bval = (DList.Node)base.get(dl);
//        System.out.println("bval: " + bval);
    }

}
