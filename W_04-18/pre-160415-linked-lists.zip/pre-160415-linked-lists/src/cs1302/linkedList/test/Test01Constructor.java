package cs1302.linkedList.test;

import static org.junit.Assert.*;

import cs1302.linkedList.SimpleList;
import org.junit.Test;

/**
 * Created by Ben on 4/13/2016.
 */
public class Test01Constructor {

    @Test
    public void testEmpty() {
        SimpleList dl = new SimpleList();
//       assertTrue(dl.hasProperStructure());
    }
}
