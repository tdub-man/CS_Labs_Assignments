package cs1302.linkedList;

import javafx.scene.shape.Circle;

/**
 * Created by Ben on 10/8/2015.
 */
public class UseLists {

    public static void main(String[] args) {
        SimpleList sl = new SimpleList();
//        sl.addLast(23);
//        sl.addLast("Something");
//        sl.addLast(new Circle());
//        System.out.println("sl size is " + sl.size());
//        for(int i = 0; i < sl.size(); i++){
//            System.out.print(sl.get(i) + " ");
//        }
//        System.out.println();

    }
}
