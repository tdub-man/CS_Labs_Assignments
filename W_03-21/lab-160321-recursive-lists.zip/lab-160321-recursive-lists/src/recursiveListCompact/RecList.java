package recursiveListCompact;

import recursiveLists.Cons;
import recursiveLists.Empty;

import java.util.Objects;

/**
 * Created by Ben on 9/16/2015.
 */
public abstract class RecList {


    public abstract Object getFirst();
    public abstract RecList getRest();
    public abstract boolean isEmpty();
    public abstract boolean equals(Object obj);

    public static RecList cons(Object f, RecList r) {
        return new Cons(f,r);
    }

    public static final RecList EMPTY = new Empty();


    // methods to do in class


    /**
     * Return the length of the list

     */
    int length() {
        if(isEmpty())
            return 0;
        else
            return 1 + getRest().length();
    }

    /**
     * Return the object at index n in the list
     * This will cause an error if n is not a valid index
     */
    Object get(int n) {
        if(n == 0)
            return getFirst();
        else
            return getRest().get(n-1);
    }

    /**
     * Create a new list with e appended to the end of a copy of this list.
     *
     */
    public RecList append(Object e) {
        if(isEmpty())
            return cons(e,this);
        else {
            Object f = getFirst();
            RecList rst = getRest().append(e);
            return  cons(f,rst);
        }
    }




    private static class Empty extends RecList{
        @Override
        public Object getFirst() {
            throw new IllegalStateException("head of empty list");
        }

        @Override
        public RecList getRest() {
            throw new IllegalStateException("tail of an empty list");
        }

        @Override
        public boolean isEmpty() {
            return true;
        }

        @Override
        public boolean equals(Object obj) {
            return obj != null && obj instanceof Empty;
        }

        @Override
        public int hashCode() {
            return -123456789;
        }
    }

    private  static class Cons extends RecList {
        private Object first;
        private RecList rest;

        public Cons(Object first, RecList rest) {
            this.first = first;
            this.rest = rest;
        }

        @Override
        public Object getFirst() {
            return first;
        }

        @Override
        public RecList getRest() {
            return rest;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean equals(Object obj) {
            if(obj == null)
                return false;
            else if(obj instanceof Cons ) {
                Cons c = (Cons)obj;
                return c.getFirst().equals(getFirst()) && c.getRest().equals(getRest());
            } else
                return false;
        }

        @Override
        public int hashCode() {
            return -12345*first.hashCode() + rest.hashCode();
        }
    }



}
