package recursiveLists;

import java.util.Objects;
import java.util.function.Function;

/**
 * Created by Ben on 9/16/2015.
 */
public abstract class RecList {


    public abstract Object getFirst();
    public abstract RecList getRest();
    public abstract boolean isEmpty();
    public abstract boolean equals(Object obj);

    public static RecList cons(Object f, RecList r) {
        return new Cons(f,r);
    }

    public static final RecList EMPTY = new Empty();


    // methods to do in class


    /**
     * Return the length of the list

     */
    int length() {
        if(isEmpty())
            return 0;
        else
            return 1 + getRest().length();
    }

    /**
     * Return the object at index n in the list
     * This will cause an error if n is not a valid index
     */
    Object get(int n) {
        if(n == 0)
            return getFirst();
        else
            return getRest().get(n-1);
    }


    /**
     * Create a new list with e appended to the end of a copy of this list.
     *
     */
    public RecList append(Object e) {
        if(isEmpty())
            return cons(e,this);
        else {
            Object f = getFirst();
            RecList rst = getRest().append(e);
            return  cons(f,rst);
        }
    }

}
