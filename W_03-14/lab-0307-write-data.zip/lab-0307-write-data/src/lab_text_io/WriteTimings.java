package lab_text_io;

import java.util.ArrayList;

/**
 * Created by Ben on 10/11/2014.
 * Revised by Ben on 9/7//2015
 */
public class WriteTimings {

    private static final int start = 128;
    private static final int limit = 20000;

    public static void main(String[] args) {
        //RandomDataList rdl = new RandomDataList(0, Integer.MAX_VALUE);
        for(int size = start; size <= limit; size += size) {
            int[] data = RandomArray.generateArray(size, 0, Integer.MAX_VALUE);
            long t0 = System.nanoTime();
            BubbleSort.sort(data);
            long t1 = System.nanoTime();
            long diff = t1 - t0;
            System.out.println("array     sort  " + size + " " + diff + " " + (double)diff/size/size);


            // repeat for array list


            System.out.println("arrayList sort  " + size + " " + diff + " " + (double)diff/size/size);


        }
    }


}
