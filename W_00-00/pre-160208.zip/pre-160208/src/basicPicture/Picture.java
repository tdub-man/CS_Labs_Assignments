package basicPicture;

public class Picture {
	private PicPoint base;

	public Picture(PicPoint base) {
		this.base = base;
	}

	public PicPoint getBase() {
		return base;
	}

	public void setBase(PicPoint base) {
		this.base = base;
	}

	
	
}
