package geometry;

/**
 * Created by Ben on 8/11/2015.
 */
public class MyTriangle {

    

}
