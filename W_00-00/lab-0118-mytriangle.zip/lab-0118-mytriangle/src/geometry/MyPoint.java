package geometry;

/**
 * Created by Ben on 1/8/2016.
 */
public class MyPoint {
    
}
