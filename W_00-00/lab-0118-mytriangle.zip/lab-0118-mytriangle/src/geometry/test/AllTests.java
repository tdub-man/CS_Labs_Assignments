package geometry.test;


import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({TestStructure.class, TestPoint.class, TestTriangle.class})
public class AllTests {


}
