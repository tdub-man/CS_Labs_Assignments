package lists.test;



import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({Test01Constructor.class, Test02AddAndGet.class,
            Test03AddAndGet.class, Test04Size.class, Test05Equals.class,
            Test06Set.class, Test07Remove.class})
public class AllTests {


}
