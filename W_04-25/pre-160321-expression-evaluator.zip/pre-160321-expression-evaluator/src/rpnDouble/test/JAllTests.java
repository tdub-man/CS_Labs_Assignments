package rpnDouble.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Created by Ben on 3/31/2015.
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({JTestCalculator1.class, JTestInterpreter1.class})
public class JAllTests {
}
